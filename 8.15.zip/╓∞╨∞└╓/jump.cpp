#include<bits/stdc++.h>

using namespace std;

typedef long long ll;
typedef double db;

const int N=2e5+50;
const int M=1e5+50;
const int Mod=1e9+7;
const int Inf=INT_MAX;

inline ll read(){
    ll x=0,f=1;
    char ch=getchar();
    while(ch<'0'||ch>'9'){
        if(ch=='-')
            f=-1;
        ch=getchar();
    }
    while(ch>='0'&&ch<='9'){
        x=(x<<1)+(x<<3)+(ch^48);
        ch=getchar();
    }
    return x*f;
}

ll t,n,l,r;

ll a[N],f[N],q[N];

ll L,R;

/*Author:RVG*/

int main()
{
	freopen("jump.in","r",stdin);
	freopen("jump.out","w",stdout);
	t=read();
	while(t--){
		n=read(),l=read(),r=read();
		for(ll i=1;i<=n;++i) a[i]=read(),f[i]=Inf;
		L=1,R=0;	
		for(ll i=1;i<=n;++i){
			if(i>=l+1){
				while(L<=R&&f[q[R]]>=f[i-l-1]) --R;
				q[++R]=i-l-1;
			}
			while(L<=R&&q[L]<i-r-1) ++L;
			if(L<=R) f[i]=a[i]+f[q[L]];
		}
		if(f[n]>=Inf) printf("-1\n"); else printf("%lld\n",f[n]);
	}
	return 0;
}
