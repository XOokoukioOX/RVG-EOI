#include<bits/stdc++.h>

using namespace std;

typedef long long ll;
typedef double db;

const int N=1e3+50;
const int M=1e5+50;
const int Mod=1e9+7;

inline int read(){
    int x=0,f=1;
    char ch=getchar();
    while(ch<'0'||ch>'9'){
        if(ch=='-')
            f=-1;
        ch=getchar();
    }
    while(ch>='0'&&ch<='9'){
        x=(x<<1)+(x<<3)+(ch^48);
        ch=getchar();
    }
    return x*f;
}

int t,n;
int a[N],f[N];

#define OUT if(cnt>=n){printf("%d\n",ans);break;}
#define WORK if(res>=a[i]&&f[i]==0) ++res,++cnt,f[i]=1;

/*Author:RVG*/

int main()
{
	freopen("task.in","r",stdin);
	freopen("task.out","w",stdout);
	t=read();
	while(t--){
		n=read();
		int ans=0,cnt=0,res=0;
		memset(f,0,sizeof(f));
		for(int i=1;i<=n;++i) a[i]=read();
		while(1){
			for(int i=1;i<=n;++i) WORK
			OUT
			++ans;
			
			for(int i=n;i>=1;--i) WORK
			OUT
			++ans;
		}
	}
	return 0;
}
