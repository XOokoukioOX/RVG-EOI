#include<bits/stdc++.h>

using namespace std;

typedef long long ll;
typedef double db;

const int N=1e5+50;
const int M=1e5+50;
const int Mod=1e9+7;

inline int read(){
    int x=0,f=1;
    char ch=getchar();
    while(ch<'0'||ch>'9'){
        if(ch=='-')
            f=-1;
        ch=getchar();
    }
    while(ch>='0'&&ch<='9'){
        x=(x<<1)+(x<<3)+(ch^48);
        ch=getchar();
    }
    return x*f;
}

int t,n,k;

struct node{
	int num,pos;
}a[N];

bool cmp(node a,node b){
	if(a.num!=b.num) return a.num<b.num;
	return a.pos<b.pos;
}

/*Author:RVG*/

int main()
{
	freopen("sequence.in","r",stdin);
	freopen("sequence.out","w",stdout);
	t=read();
	while(t--){
		n=read(),k=read();
		for(int i=1;i<=n;++i) a[i].num=read(),a[i].pos=i;
		sort(a+1,a+n+1,cmp);
		int ans=1,res=1,tmp=k,l=0;
		for(int i=2;i<=n;++i){
			if(a[i].num==a[i-1].num){
				++res,tmp-=a[i].pos-a[i-1].pos-1;
				while(tmp<0) --res,tmp+=a[l+1].pos-a[l].pos-1,++l;
				ans=max(ans,res);
			}else{
				l=i,tmp=k,res=1;
			}
		}
		printf("%d\n",ans);
	}
	return 0;
}
